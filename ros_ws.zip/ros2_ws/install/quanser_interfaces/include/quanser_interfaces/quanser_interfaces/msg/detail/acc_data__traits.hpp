// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from quanser_interfaces:msg/AccData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__TRAITS_HPP_
#define QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "quanser_interfaces/msg/detail/acc_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace quanser_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const AccData & msg,
  std::ostream & out)
{
  out << "{";
  // member: acc_x
  {
    out << "acc_x: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_x, out);
    out << ", ";
  }

  // member: acc_y
  {
    out << "acc_y: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_y, out);
    out << ", ";
  }

  // member: acc_z
  {
    out << "acc_z: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_z, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AccData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: acc_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc_x: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_x, out);
    out << "\n";
  }

  // member: acc_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc_y: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_y, out);
    out << "\n";
  }

  // member: acc_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc_z: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_z, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AccData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace quanser_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use quanser_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const quanser_interfaces::msg::AccData & msg,
  std::ostream & out, size_t indentation = 0)
{
  quanser_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use quanser_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const quanser_interfaces::msg::AccData & msg)
{
  return quanser_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<quanser_interfaces::msg::AccData>()
{
  return "quanser_interfaces::msg::AccData";
}

template<>
inline const char * name<quanser_interfaces::msg::AccData>()
{
  return "quanser_interfaces/msg/AccData";
}

template<>
struct has_fixed_size<quanser_interfaces::msg::AccData>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<quanser_interfaces::msg::AccData>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<quanser_interfaces::msg::AccData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__TRAITS_HPP_
