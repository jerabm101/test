// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from quanser_interfaces:msg/AccData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__STRUCT_H_
#define QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/AccData in the package quanser_interfaces.
/**
  * Accelerometer data x,y,z axis
 */
typedef struct quanser_interfaces__msg__AccData
{
  double acc_x;
  double acc_y;
  double acc_z;
} quanser_interfaces__msg__AccData;

// Struct for a sequence of quanser_interfaces__msg__AccData.
typedef struct quanser_interfaces__msg__AccData__Sequence
{
  quanser_interfaces__msg__AccData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} quanser_interfaces__msg__AccData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__STRUCT_H_
