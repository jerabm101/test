// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from quanser_interfaces:msg/CameraData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__CAMERA_DATA__BUILDER_HPP_
#define QUANSER_INTERFACES__MSG__DETAIL__CAMERA_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "quanser_interfaces/msg/detail/camera_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace quanser_interfaces
{

namespace msg
{

namespace builder
{

class Init_CameraData_data
{
public:
  explicit Init_CameraData_data(::quanser_interfaces::msg::CameraData & msg)
  : msg_(msg)
  {}
  ::quanser_interfaces::msg::CameraData data(::quanser_interfaces::msg::CameraData::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

class Init_CameraData_step
{
public:
  explicit Init_CameraData_step(::quanser_interfaces::msg::CameraData & msg)
  : msg_(msg)
  {}
  Init_CameraData_data step(::quanser_interfaces::msg::CameraData::_step_type arg)
  {
    msg_.step = std::move(arg);
    return Init_CameraData_data(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

class Init_CameraData_is_bigendian
{
public:
  explicit Init_CameraData_is_bigendian(::quanser_interfaces::msg::CameraData & msg)
  : msg_(msg)
  {}
  Init_CameraData_step is_bigendian(::quanser_interfaces::msg::CameraData::_is_bigendian_type arg)
  {
    msg_.is_bigendian = std::move(arg);
    return Init_CameraData_step(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

class Init_CameraData_encoding
{
public:
  explicit Init_CameraData_encoding(::quanser_interfaces::msg::CameraData & msg)
  : msg_(msg)
  {}
  Init_CameraData_is_bigendian encoding(::quanser_interfaces::msg::CameraData::_encoding_type arg)
  {
    msg_.encoding = std::move(arg);
    return Init_CameraData_is_bigendian(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

class Init_CameraData_width
{
public:
  explicit Init_CameraData_width(::quanser_interfaces::msg::CameraData & msg)
  : msg_(msg)
  {}
  Init_CameraData_encoding width(::quanser_interfaces::msg::CameraData::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_CameraData_encoding(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

class Init_CameraData_height
{
public:
  explicit Init_CameraData_height(::quanser_interfaces::msg::CameraData & msg)
  : msg_(msg)
  {}
  Init_CameraData_width height(::quanser_interfaces::msg::CameraData::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_CameraData_width(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

class Init_CameraData_header
{
public:
  Init_CameraData_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CameraData_height header(::quanser_interfaces::msg::CameraData::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CameraData_height(msg_);
  }

private:
  ::quanser_interfaces::msg::CameraData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::quanser_interfaces::msg::CameraData>()
{
  return quanser_interfaces::msg::builder::Init_CameraData_header();
}

}  // namespace quanser_interfaces

#endif  // QUANSER_INTERFACES__MSG__DETAIL__CAMERA_DATA__BUILDER_HPP_
