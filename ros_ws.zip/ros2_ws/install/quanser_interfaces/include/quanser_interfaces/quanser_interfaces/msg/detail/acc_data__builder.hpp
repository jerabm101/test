// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from quanser_interfaces:msg/AccData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__BUILDER_HPP_
#define QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "quanser_interfaces/msg/detail/acc_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace quanser_interfaces
{

namespace msg
{

namespace builder
{

class Init_AccData_acc_z
{
public:
  explicit Init_AccData_acc_z(::quanser_interfaces::msg::AccData & msg)
  : msg_(msg)
  {}
  ::quanser_interfaces::msg::AccData acc_z(::quanser_interfaces::msg::AccData::_acc_z_type arg)
  {
    msg_.acc_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::quanser_interfaces::msg::AccData msg_;
};

class Init_AccData_acc_y
{
public:
  explicit Init_AccData_acc_y(::quanser_interfaces::msg::AccData & msg)
  : msg_(msg)
  {}
  Init_AccData_acc_z acc_y(::quanser_interfaces::msg::AccData::_acc_y_type arg)
  {
    msg_.acc_y = std::move(arg);
    return Init_AccData_acc_z(msg_);
  }

private:
  ::quanser_interfaces::msg::AccData msg_;
};

class Init_AccData_acc_x
{
public:
  Init_AccData_acc_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AccData_acc_y acc_x(::quanser_interfaces::msg::AccData::_acc_x_type arg)
  {
    msg_.acc_x = std::move(arg);
    return Init_AccData_acc_y(msg_);
  }

private:
  ::quanser_interfaces::msg::AccData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::quanser_interfaces::msg::AccData>()
{
  return quanser_interfaces::msg::builder::Init_AccData_acc_x();
}

}  // namespace quanser_interfaces

#endif  // QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__BUILDER_HPP_
