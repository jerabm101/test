// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from quanser_interfaces:msg/AccData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__STRUCT_HPP_
#define QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__quanser_interfaces__msg__AccData __attribute__((deprecated))
#else
# define DEPRECATED__quanser_interfaces__msg__AccData __declspec(deprecated)
#endif

namespace quanser_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AccData_
{
  using Type = AccData_<ContainerAllocator>;

  explicit AccData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->acc_x = 0.0;
      this->acc_y = 0.0;
      this->acc_z = 0.0;
    }
  }

  explicit AccData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->acc_x = 0.0;
      this->acc_y = 0.0;
      this->acc_z = 0.0;
    }
  }

  // field types and members
  using _acc_x_type =
    double;
  _acc_x_type acc_x;
  using _acc_y_type =
    double;
  _acc_y_type acc_y;
  using _acc_z_type =
    double;
  _acc_z_type acc_z;

  // setters for named parameter idiom
  Type & set__acc_x(
    const double & _arg)
  {
    this->acc_x = _arg;
    return *this;
  }
  Type & set__acc_y(
    const double & _arg)
  {
    this->acc_y = _arg;
    return *this;
  }
  Type & set__acc_z(
    const double & _arg)
  {
    this->acc_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    quanser_interfaces::msg::AccData_<ContainerAllocator> *;
  using ConstRawPtr =
    const quanser_interfaces::msg::AccData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      quanser_interfaces::msg::AccData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      quanser_interfaces::msg::AccData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__quanser_interfaces__msg__AccData
    std::shared_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__quanser_interfaces__msg__AccData
    std::shared_ptr<quanser_interfaces::msg::AccData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AccData_ & other) const
  {
    if (this->acc_x != other.acc_x) {
      return false;
    }
    if (this->acc_y != other.acc_y) {
      return false;
    }
    if (this->acc_z != other.acc_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const AccData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AccData_

// alias to use template instance with default allocator
using AccData =
  quanser_interfaces::msg::AccData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace quanser_interfaces

#endif  // QUANSER_INTERFACES__MSG__DETAIL__ACC_DATA__STRUCT_HPP_
