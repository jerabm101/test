// generated from rosidl_generator_c/resource/idl.h.em
// with input from quanser_interfaces:msg/AccData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__ACC_DATA_H_
#define QUANSER_INTERFACES__MSG__ACC_DATA_H_

#include "quanser_interfaces/msg/detail/acc_data__struct.h"
#include "quanser_interfaces/msg/detail/acc_data__functions.h"
#include "quanser_interfaces/msg/detail/acc_data__type_support.h"

#endif  // QUANSER_INTERFACES__MSG__ACC_DATA_H_
