// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from quanser_interfaces:msg/Image.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__IMAGE__BUILDER_HPP_
#define QUANSER_INTERFACES__MSG__DETAIL__IMAGE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "quanser_interfaces/msg/detail/image__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace quanser_interfaces
{

namespace msg
{

namespace builder
{

class Init_Image_data
{
public:
  explicit Init_Image_data(::quanser_interfaces::msg::Image & msg)
  : msg_(msg)
  {}
  ::quanser_interfaces::msg::Image data(::quanser_interfaces::msg::Image::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

class Init_Image_step
{
public:
  explicit Init_Image_step(::quanser_interfaces::msg::Image & msg)
  : msg_(msg)
  {}
  Init_Image_data step(::quanser_interfaces::msg::Image::_step_type arg)
  {
    msg_.step = std::move(arg);
    return Init_Image_data(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

class Init_Image_is_bigendian
{
public:
  explicit Init_Image_is_bigendian(::quanser_interfaces::msg::Image & msg)
  : msg_(msg)
  {}
  Init_Image_step is_bigendian(::quanser_interfaces::msg::Image::_is_bigendian_type arg)
  {
    msg_.is_bigendian = std::move(arg);
    return Init_Image_step(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

class Init_Image_encoding
{
public:
  explicit Init_Image_encoding(::quanser_interfaces::msg::Image & msg)
  : msg_(msg)
  {}
  Init_Image_is_bigendian encoding(::quanser_interfaces::msg::Image::_encoding_type arg)
  {
    msg_.encoding = std::move(arg);
    return Init_Image_is_bigendian(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

class Init_Image_width
{
public:
  explicit Init_Image_width(::quanser_interfaces::msg::Image & msg)
  : msg_(msg)
  {}
  Init_Image_encoding width(::quanser_interfaces::msg::Image::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_Image_encoding(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

class Init_Image_height
{
public:
  explicit Init_Image_height(::quanser_interfaces::msg::Image & msg)
  : msg_(msg)
  {}
  Init_Image_width height(::quanser_interfaces::msg::Image::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_Image_width(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

class Init_Image_header
{
public:
  Init_Image_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Image_height header(::quanser_interfaces::msg::Image::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Image_height(msg_);
  }

private:
  ::quanser_interfaces::msg::Image msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::quanser_interfaces::msg::Image>()
{
  return quanser_interfaces::msg::builder::Init_Image_header();
}

}  // namespace quanser_interfaces

#endif  // QUANSER_INTERFACES__MSG__DETAIL__IMAGE__BUILDER_HPP_
