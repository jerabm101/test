// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from quanser_interfaces:msg/GyroData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__GYRO_DATA__BUILDER_HPP_
#define QUANSER_INTERFACES__MSG__DETAIL__GYRO_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "quanser_interfaces/msg/detail/gyro_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace quanser_interfaces
{

namespace msg
{

namespace builder
{

class Init_GyroData_gyro_z
{
public:
  explicit Init_GyroData_gyro_z(::quanser_interfaces::msg::GyroData & msg)
  : msg_(msg)
  {}
  ::quanser_interfaces::msg::GyroData gyro_z(::quanser_interfaces::msg::GyroData::_gyro_z_type arg)
  {
    msg_.gyro_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::quanser_interfaces::msg::GyroData msg_;
};

class Init_GyroData_gyro_y
{
public:
  explicit Init_GyroData_gyro_y(::quanser_interfaces::msg::GyroData & msg)
  : msg_(msg)
  {}
  Init_GyroData_gyro_z gyro_y(::quanser_interfaces::msg::GyroData::_gyro_y_type arg)
  {
    msg_.gyro_y = std::move(arg);
    return Init_GyroData_gyro_z(msg_);
  }

private:
  ::quanser_interfaces::msg::GyroData msg_;
};

class Init_GyroData_gyro_x
{
public:
  Init_GyroData_gyro_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GyroData_gyro_y gyro_x(::quanser_interfaces::msg::GyroData::_gyro_x_type arg)
  {
    msg_.gyro_x = std::move(arg);
    return Init_GyroData_gyro_y(msg_);
  }

private:
  ::quanser_interfaces::msg::GyroData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::quanser_interfaces::msg::GyroData>()
{
  return quanser_interfaces::msg::builder::Init_GyroData_gyro_x();
}

}  // namespace quanser_interfaces

#endif  // QUANSER_INTERFACES__MSG__DETAIL__GYRO_DATA__BUILDER_HPP_
