// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from quanser_interfaces:msg/GyroData.idl
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__DETAIL__GYRO_DATA__STRUCT_H_
#define QUANSER_INTERFACES__MSG__DETAIL__GYRO_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/GyroData in the package quanser_interfaces.
/**
  * Gyroscope data x,y,z axis
 */
typedef struct quanser_interfaces__msg__GyroData
{
  double gyro_x;
  double gyro_y;
  double gyro_z;
} quanser_interfaces__msg__GyroData;

// Struct for a sequence of quanser_interfaces__msg__GyroData.
typedef struct quanser_interfaces__msg__GyroData__Sequence
{
  quanser_interfaces__msg__GyroData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} quanser_interfaces__msg__GyroData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // QUANSER_INTERFACES__MSG__DETAIL__GYRO_DATA__STRUCT_H_
