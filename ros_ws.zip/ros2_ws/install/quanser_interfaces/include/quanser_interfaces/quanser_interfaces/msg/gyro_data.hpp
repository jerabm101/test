// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef QUANSER_INTERFACES__MSG__GYRO_DATA_HPP_
#define QUANSER_INTERFACES__MSG__GYRO_DATA_HPP_

#include "quanser_interfaces/msg/detail/gyro_data__struct.hpp"
#include "quanser_interfaces/msg/detail/gyro_data__builder.hpp"
#include "quanser_interfaces/msg/detail/gyro_data__traits.hpp"

#endif  // QUANSER_INTERFACES__MSG__GYRO_DATA_HPP_
