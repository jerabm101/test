// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from quanser_interfaces:msg/GyroData.idl
// generated code does not contain a copyright notice
#include "quanser_interfaces/msg/detail/gyro_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
quanser_interfaces__msg__GyroData__init(quanser_interfaces__msg__GyroData * msg)
{
  if (!msg) {
    return false;
  }
  // gyro_x
  // gyro_y
  // gyro_z
  return true;
}

void
quanser_interfaces__msg__GyroData__fini(quanser_interfaces__msg__GyroData * msg)
{
  if (!msg) {
    return;
  }
  // gyro_x
  // gyro_y
  // gyro_z
}

bool
quanser_interfaces__msg__GyroData__are_equal(const quanser_interfaces__msg__GyroData * lhs, const quanser_interfaces__msg__GyroData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // gyro_x
  if (lhs->gyro_x != rhs->gyro_x) {
    return false;
  }
  // gyro_y
  if (lhs->gyro_y != rhs->gyro_y) {
    return false;
  }
  // gyro_z
  if (lhs->gyro_z != rhs->gyro_z) {
    return false;
  }
  return true;
}

bool
quanser_interfaces__msg__GyroData__copy(
  const quanser_interfaces__msg__GyroData * input,
  quanser_interfaces__msg__GyroData * output)
{
  if (!input || !output) {
    return false;
  }
  // gyro_x
  output->gyro_x = input->gyro_x;
  // gyro_y
  output->gyro_y = input->gyro_y;
  // gyro_z
  output->gyro_z = input->gyro_z;
  return true;
}

quanser_interfaces__msg__GyroData *
quanser_interfaces__msg__GyroData__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  quanser_interfaces__msg__GyroData * msg = (quanser_interfaces__msg__GyroData *)allocator.allocate(sizeof(quanser_interfaces__msg__GyroData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(quanser_interfaces__msg__GyroData));
  bool success = quanser_interfaces__msg__GyroData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
quanser_interfaces__msg__GyroData__destroy(quanser_interfaces__msg__GyroData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    quanser_interfaces__msg__GyroData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
quanser_interfaces__msg__GyroData__Sequence__init(quanser_interfaces__msg__GyroData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  quanser_interfaces__msg__GyroData * data = NULL;

  if (size) {
    data = (quanser_interfaces__msg__GyroData *)allocator.zero_allocate(size, sizeof(quanser_interfaces__msg__GyroData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = quanser_interfaces__msg__GyroData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        quanser_interfaces__msg__GyroData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
quanser_interfaces__msg__GyroData__Sequence__fini(quanser_interfaces__msg__GyroData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      quanser_interfaces__msg__GyroData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

quanser_interfaces__msg__GyroData__Sequence *
quanser_interfaces__msg__GyroData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  quanser_interfaces__msg__GyroData__Sequence * array = (quanser_interfaces__msg__GyroData__Sequence *)allocator.allocate(sizeof(quanser_interfaces__msg__GyroData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = quanser_interfaces__msg__GyroData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
quanser_interfaces__msg__GyroData__Sequence__destroy(quanser_interfaces__msg__GyroData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    quanser_interfaces__msg__GyroData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
quanser_interfaces__msg__GyroData__Sequence__are_equal(const quanser_interfaces__msg__GyroData__Sequence * lhs, const quanser_interfaces__msg__GyroData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!quanser_interfaces__msg__GyroData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
quanser_interfaces__msg__GyroData__Sequence__copy(
  const quanser_interfaces__msg__GyroData__Sequence * input,
  quanser_interfaces__msg__GyroData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(quanser_interfaces__msg__GyroData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    quanser_interfaces__msg__GyroData * data =
      (quanser_interfaces__msg__GyroData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!quanser_interfaces__msg__GyroData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          quanser_interfaces__msg__GyroData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!quanser_interfaces__msg__GyroData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
