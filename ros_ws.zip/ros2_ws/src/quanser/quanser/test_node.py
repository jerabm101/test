#!/usr/bin/env python3
import threading
from quanser.tcp_manager import TCPManager
import yaml
from sensor_msgs.msg import Image
import rclpy
from rclpy.node import Node

class MyNode(Node):

    def __init__(self):
        super().__init__("test_node")
        self.create_timer(1, self.timer_callback)

        #with open("tcpConfiguration.yaml", "r") as file:
        #    config = yaml.safe_load(file)
        #self.tcp_manager = TCPManager(config["QCarIP"], config["CarToROSPort"], config["ROSToCarPort"])
        self.tcp_manager = TCPManager('localhost', 5555, 5556)
        self.carData = dict()
        self.camerasData = dict()
        self.carDataLock = threading.Lock()
        self.camerasDataLock = threading.Lock()


    def timer_callback(self):
        self.get_logger().info("GUTHIB")
    

    def cyclicReceiveTCP(self):        
        while True:
            msg = self.tcp_manager.receive_msg()
            if (msg is not None):
                if (msg["Type"] == "CarData"):
                    self.carDataLock.acquire()
                    self.carData = msg
                    self.carDataLock.release()
                elif (msg["Type"] == "CamerasData"):
                    self.camerasDataLock.acquire()
                    self.camerasData = msg
                    self.camerasDataLock.release()
            continue

    
    def send_array(self):
        # Initialize the ROS node
        rclpy.init()

        # Create a publisher to send the numpy array
        array_pub = rclpy.create_publisher(Image, 'CameraRGB', 0)

        # Create a ROS rate object to control the publishing rate
        rate = rclpy.Rate(100)  # 100 Hz

        while (rclpy.ok() or self.shutDownRequired):
            # Convert the numpy array to a Image message
            array_msg = Image()
            
            if("realSenseRGBData" in self.camerasData.keys()):
                self.camerasDataLock.acquire()
                array_msg.data = self.camerasData["realSenseRGBData"].flatten().tolist()
                self.camerasDataLock.release()
            # Publish the array message
            array_pub.publish(array_msg)

            # Sleep to maintain the desired publishing rate
            rate.sleep()


def main(args=None):
    rclpy.init(args=args)
    data_publisher = MyNode()
    receive_thread = threading.Thread(target=data_publisher.cyclicReceiveTCP)
    send_thread = threading.Thread(target=data_publisher.send_array)
    
    # Start the threads
    receive_thread.start()
    send_thread.start()
    
    # Wait for the threads to finish
    receive_thread.join()
    send_thread.join()
    rclpy.shutdown()

if __name__ == '__main__':
    main(   )